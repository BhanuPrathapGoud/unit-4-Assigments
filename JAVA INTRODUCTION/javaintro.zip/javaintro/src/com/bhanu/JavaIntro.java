package com.bhanu;

public class JavaIntro {
    public static void main( String [] args){
        System.out.println("Name : Bhanu Prathap" );
        System.out.println("Father’s Name : Srishailam" );
        System.out.println("Mother’s Name : vasantha" );
        System.out.println("Age : 23" );
        System.out.println("Gender : Male" );
        System.out.println("Adress : Hyderabad");
        System.out.println("Phone no : 9160304568");


    }
}
//Name : XYZ
//
//        Father’s Name : XYZ
//
//        Mother ‘s Name : XYZ
//
//        Age : XYZ
//
//        Gender : XYZ
//
//        Address : XYZ
//
//        Mobile No. : XYZ