package com.question1;

public class Square {
    public int side;
    public Square(int side){
        this.side = side;
    }
}
