package com.question1;

public class Circle {
    public int radius;
    public Circle(int radius){

       this.radius = radius;

    }
}
