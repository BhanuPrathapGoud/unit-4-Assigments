package com.question1;

public class Rectangle {
     public int length;
    public int width;
    public Rectangle(int length, int width){
        this.length = length;
        this.width = width;
    }
}