package com.question1;

public interface Z extends X,Y{
    void functionZAbstract();

}
